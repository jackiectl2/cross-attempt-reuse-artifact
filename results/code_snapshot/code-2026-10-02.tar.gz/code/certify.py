"""Contract B certificate: is a query's serialized result byte-stable on a pinned snapshot?

Conservative static check on the query text only (deployable at runtime):
  1. single read-only statement;
  2. every LIMIT/OFFSET sits in a scope whose ORDER BY covers that scope's outputs;
  3. no order-sensitive window or aggregate (string_agg, group_concat, first, ...);
  4. every function is on a deterministic allowlist; no 'now' literals;
  5. the result has at most one row by construction, or the top-level ORDER BY
     covers every output column.
MongoDB (DAB interface: collection/filter/projection/limit, no sort): only an
equality filter on `_id` (at most one document) is certified.
"""
import sys
import json
import warnings

import sqlglot
from sqlglot import exp

_ALLOWED_CLASSES = tuple(c for c in (getattr(exp, n, None) for n in (
    "Count", "Sum", "Avg", "Min", "Max", "Coalesce", "Cast", "TryCast", "Round", "Abs", "Upper", "Lower",
    "Length", "Substring", "Trim", "Concat", "ConcatWs", "Replace", "StrPosition", "Extract", "Nullif",
    "Greatest", "Least", "Floor", "Ceil", "Sqrt", "Pow", "Ln", "Log", "Exp", "Sign", "If", "Case",
    "Left", "Right", "Pad", "RegexpLike", "RegexpExtract", "RegexpReplace", "StrToDate", "StrToTime",
    "TimeToStr", "DateDiff", "DateAdd", "DateSub", "DateTrunc", "TimestampTrunc", "Year", "Month", "Day",
    "Quarter", "Date", "TsOrDsToDate", "TimeStrToTime", "UnixToTime", "JSONExtract", "JSONExtractScalar",
    "Variance", "VariancePop", "Stddev", "StddevPop", "StddevSamp", "Median", "PercentileCont",
    "PercentileDisc", "Quantile", "CountIf", "SafeDivide", "Div", "IsNan", "Initcap", "Reverse",
    "Ascii", "Chr", "Hex", "MD5", "Levenshtein", "StartsWith", "EndsWith", "Contains", "SplitPart",
    "ToChar", "TsOrDsToTimestamp", "RegexpILike", "Like", "ILike", "In", "Between", "Distinct",
    "StrToUnix", "UnixToStr", "Array", "Struct", "Bracket", "JSONBExtract", "JSONBExtractScalar")) if c is not None)
_ALLOWED_ANON = {
    "strftime", "date", "julianday", "substr", "instr", "printf", "ifnull", "iif", "regexp_matches",
    "regexp_extract", "regexp_replace", "split_part", "year", "month", "day", "json_extract", "ltrim",
    "rtrim", "trim", "lower", "upper", "length", "round", "abs", "typeof", "unicode", "char", "hex",
    "total", "contains", "starts_with", "ends_with", "epoch", "date_part", "datepart", "to_char",
    "to_date", "to_timestamp", "log", "ln", "power", "pow", "sqrt", "floor", "ceil", "ceiling", "sign",
    "mod", "levenshtein", "ascii", "strpos", "position", "left", "right", "replace", "reverse", "lpad",
    "rpad", "concat", "concat_ws", "regexp_like", "regexp_substr", "try_cast", "cast", "coalesce",
    "nullif", "greatest", "least", "count", "sum", "avg", "min", "max", "strptime", "date_trunc",
    "make_date", "extract", "json_extract_string", "json_extract_path_text", "lower", "nullif",
    "try_strptime", "regexp_full_match", "string_split", "len", "list_contains", "array_length", "cardinality",
}
_ORDER_SENSITIVE_ANON = {"group_concat", "string_agg", "listagg", "list", "array_agg", "json_group_array",
                         "first", "last", "any_value", "arbitrary", "first_value", "last_value", "nth_value",
                         "row_number", "rank", "dense_rank", "ntile", "lag", "lead", "random", "rand",
                         "now", "uuid", "gen_random_uuid", "current_date", "current_timestamp"}
# SQLite-style temporal functions read the clock when the time-value argument is omitted.
_CLOCK_MIN_ARGS = {"date": 1, "time": 1, "datetime": 1, "julianday": 1, "unixepoch": 1, "strftime": 2,
                   "ts_or_ds_to_date": 1, "time_str_to_time": 1, "str_to_time": 1, "time_to_str": 2,
                   "ts_or_ds_to_timestamp": 1}
_VOLATILE_ANON = {"random", "rand", "now", "uuid", "gen_random_uuid", "current_date", "current_timestamp"}
_ORDER_DEP_CLASSES = tuple(c for c in (getattr(exp, n, None) for n in (
    "GroupConcat", "ArrayAgg", "First", "Last", "AnyValue", "RowNumber", "Rank", "DenseRank", "Ntile",
    "Lag", "Lead", "FirstValue", "LastValue", "NthValue", "ArgMax", "ArgMin")) if c is not None)
_SAFE_WINDOW_AGGS = tuple(getattr(exp, n) for n in ("Count", "Sum", "Avg", "Min", "Max"))
_DIALECT = {"sqlite": "sqlite", "duckdb": "duckdb", "postgres": "postgres"}


def _out_keys(scope):
    """SQL strings by which each output column of a scope can be ordered (expr, and alias if unique)."""
    sel = scope
    while isinstance(sel, exp.SetOperation):
        sel = sel.left
    if not isinstance(sel, exp.Select):
        return None
    names = [p.alias_or_name.lower() for p in sel.expressions]
    keys = []
    for p, name in zip(sel.expressions, names):
        if p.is_star:
            return None
        inner = p.this if isinstance(p, exp.Alias) else p
        k = {inner.sql().lower()}
        if names.count(name) == 1:
            k.add(name)
        keys.append(k)
    return keys


def _order_covers(scope):
    order = scope.args.get("order")
    outs = _out_keys(scope)
    if order is None or outs is None:
        return False
    order_keys = set()
    for o in order.expressions:
        e = o.this if isinstance(o, exp.Ordered) else o
        if isinstance(e, exp.Literal) and e.is_int:
            i = int(e.this) - 1
            if 0 <= i < len(outs):
                order_keys |= outs[i]
            continue
        order_keys.add(e.sql().lower())
        if isinstance(e, exp.Column):
            order_keys.add(e.name.lower())
    return all(k & order_keys for k in outs)


def _has(node, cls):
    """sqlglot's find() does not test the node itself."""
    return isinstance(node, cls) or node.find(cls) is not None


def _under_agg(node, root):
    while node is not None:
        if isinstance(node, exp.AggFunc):
            return True
        if node is root:
            return False
        node = node.parent
    return False


def _at_most_one_row(top):
    """Top-level aggregate without GROUP BY whose every column reference sits under an aggregate."""
    if not isinstance(top, exp.Select) or top.args.get("group") or top.find(exp.Window):
        return False
    for p in top.expressions:
        if not _has(p, exp.AggFunc) or _has(p, exp.Subquery):
            return False
        if any(not _under_agg(c, p) for c in p.find_all(exp.Column)):
            return False
    return bool(top.expressions)


def certify_sql(text, engine, strict=True):
    """strict=True: Contract B (static certificate). strict=False: Contract E (exploratory, added after the
    B coverage measurement): byte stability rests on the pinned runtime (engine version, single thread,
    static snapshot); ordering/shape checks are dropped, read-only/volatility/allowlist checks are kept."""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            stmts = [s for s in sqlglot.parse(text, read=_DIALECT[engine]) if s is not None]
    except Exception:
        return False, "parse_error"
    if len(stmts) != 1:
        return False, "not_single_statement"
    top = stmts[0]
    if not isinstance(top, (exp.Select, exp.SetOperation)):
        return False, "not_select"
    if top.find(exp.Insert, exp.Update, exp.Delete, exp.Create, exp.Drop, exp.Command):
        return False, "not_read_only"
    if top.find(exp.TableSample):
        return False, "table_sample"
    for lit in top.find_all(exp.Literal):
        if lit.is_string and lit.this.strip().lower() in ("now", "localtime"):
            return False, "volatile_literal"
    for sq in top.find_all(exp.Subquery):
        parent = sq.parent
        if isinstance(parent, (exp.From, exp.Join, exp.In, exp.Exists)):
            continue
        inner = sq.this
        if strict and not _at_most_one_row(inner):
            return False, "scalar_subquery"
    for node in (top.find_all(exp.Limit, exp.Offset) if strict else ()):
        scope = node.parent
        if not isinstance(scope, (exp.Select, exp.SetOperation)) or not _order_covers(scope):
            return False, "unordered_limit"
    for w in (top.find_all(exp.Window) if strict else ()):
        if w.args.get("order") is not None or not isinstance(w.this, _SAFE_WINDOW_AGGS):
            return False, "order_sensitive_window"
    for f in top.find_all(exp.Func):
        if isinstance(f, (exp.Window, exp.Connector, exp.Predicate, exp.Binary, exp.Unary, exp.Paren)):
            continue                                   # boolean/comparison operators, not functions
        fname = (str(f.this) if isinstance(f, exp.Anonymous) else f.sql_name()).lower()
        n_args = sum(1 for _ in f.iter_expressions())
        if fname in _CLOCK_MIN_ARGS and n_args < _CLOCK_MIN_ARGS[fname]:
            return False, f"implicit_now:{fname}"
        if isinstance(f, exp.Anonymous):
            name = str(f.this).lower()
            if name in _VOLATILE_ANON or (strict and name in _ORDER_SENSITIVE_ANON) or \
                    (name not in _ALLOWED_ANON and not (not strict and name in _ORDER_SENSITIVE_ANON)):
                return False, f"function:{name}"
        elif not isinstance(f, _ALLOWED_CLASSES) and not (not strict and isinstance(f, _ORDER_DEP_CLASSES)):
            return False, f"function:{type(f).__name__}"
    if not strict:
        return True, "pinned_runtime"
    if _at_most_one_row(top):
        return True, "one_row"
    if _order_covers(top):
        return True, "total_order"
    return False, "unordered_result"


def certify_mongo(text, strict=True):
    try:
        q = json.loads(text)
    except Exception:
        return False, "parse_error"
    if not isinstance(q, dict):
        return False, "not_find_spec"
    f = q.get("filter") or {}
    if isinstance(f, dict) and "_id" in f and not isinstance(f["_id"], (dict, list)):
        return True, "id_lookup"
    if not strict:
        return True, "pinned_runtime"
    return False, "mongo_no_sort"


def certify(text, engine, strict=True):
    if engine == "mongo":
        return certify_mongo(text, strict)
    return certify_sql(text, engine, strict)


if __name__ == "__main__":
    cases = [
        ("SELECT COUNT(*) FROM t", "sqlite", True),
        ("SELECT a, b FROM t ORDER BY a, b", "duckdb", True),
        ("SELECT a, b FROM t ORDER BY a", "duckdb", False),
        ("SELECT a FROM t LIMIT 5", "sqlite", False),
        ("SELECT SUM(x) FROM (SELECT x FROM t LIMIT 10) s", "duckdb", False),
        ("SELECT SUM(x) FROM (SELECT x FROM t ORDER BY x LIMIT 10) s", "duckdb", True),
        ("SELECT * FROM t", "sqlite", False),
        ("SELECT group_concat(a) FROM t", "sqlite", False),
        ("SELECT strftime('%Y', 'now')", "sqlite", False),
        ("SELECT AVG(r) AS m FROM t WHERE y > 2000", "postgres", True),
        ("SELECT a, COUNT(*) c FROM t GROUP BY a ORDER BY c DESC", "duckdb", False),
        ("SELECT a, COUNT(*) c FROM t GROUP BY a ORDER BY c DESC, a", "duckdb", True),
        ("SELECT row_number() OVER (ORDER BY a) FROM t", "duckdb", False),
        ("SELECT a FROM t ORDER BY 1", "sqlite", True),
        ("INSERT INTO t VALUES (1)", "sqlite", False),
        ("SELECT random()", "duckdb", False),
        ("SELECT date() ORDER BY 1", "sqlite", False),
        ("SELECT strftime('%Y')", "sqlite", False),
        ("SELECT SUM(x) FROM t TABLESAMPLE SYSTEM (10)", "postgres", False),
        ("SELECT COUNT(*), name || MIN('') FROM t", "sqlite", False),
        ("SELECT a AS x, b AS x FROM t ORDER BY x", "duckdb", False),
        ("SELECT COUNT(*), (SELECT b FROM u) FROM t", "sqlite", False),
        ("SELECT strftime('%Y', d) AS y, COUNT(*) AS c FROM t GROUP BY y ORDER BY y, c", "sqlite", True),
        ("SELECT COUNT(*) FROM t WHERE a = 1 AND (b LIKE 'x%' OR c IN (1, 2)) AND d BETWEEN 1 AND 5", "postgres", True),
        ("SELECT a FROM t WHERE a > 1 AND b < 2 ORDER BY a", "duckdb", True),
        ("SELECT (SELECT a FROM t) AS x ORDER BY 1", "sqlite", False),
        ("SELECT a FROM t WHERE b = (SELECT MAX(b) FROM t) ORDER BY a", "sqlite", True),
        ("SELECT a FROM t WHERE b IN (SELECT b FROM u) ORDER BY a", "duckdb", True),
    ]
    bad = 0
    for q, e, want in cases:
        got, why = certify(q, e)
        flag = "ok " if got == want else "BAD"
        bad += got != want
        print(f"{flag} {got!s:5} {why:24} {q}")
    for q, want in (('{"collection": "b", "filter": {"_id": "x"}}', True), ('{"collection": "b", "limit": 5}', False)):
        got, why = certify(q, "mongo")
        bad += got != want
        print(f"{'ok ' if got == want else 'BAD'} {got!s:5} {why:24} mongo {q}")
    for q, e, want_e in [("SELECT a FROM t LIMIT 5", "sqlite", True), ("SELECT group_concat(a) FROM t", "sqlite", True),
                         ("SELECT random()", "duckdb", False), ("SELECT date() ORDER BY 1", "sqlite", False),
                         ("SELECT SUM(x) FROM t TABLESAMPLE SYSTEM (10)", "postgres", False)]:
        got, why = certify(q, e, strict=False)
        bad += got != want_e
        print(f"{'ok ' if got == want_e else 'BAD'} E:{got!s:5} {why:24} {q}")
    n = len(cases) + 2 + 5
    print(f"unit tests: {n} assertions ({len(cases)} SQL B, 2 Mongo B, 5 E), failures: {bad}")
    sys.exit(1 if bad else 0)
